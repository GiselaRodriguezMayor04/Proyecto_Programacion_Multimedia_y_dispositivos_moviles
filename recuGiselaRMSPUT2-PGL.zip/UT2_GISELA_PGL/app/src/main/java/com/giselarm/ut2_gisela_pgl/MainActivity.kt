package com.giselarm.ut2_gisela_pgl

import android.annotation.SuppressLint
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.List
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Button
import androidx.compose.material3.DrawerValue
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ModalDrawerSheet
import androidx.compose.material3.ModalNavigationDrawer
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationDrawerItem
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.rememberDrawerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.giselarm.ut2_gisela_pgl.ui.theme.UT2_GISELA_PGLTheme
import com.google.android.gms.maps.model.CameraPosition
import com.google.android.gms.maps.model.LatLng
import com.google.firebase.firestore.FirebaseFirestore
import com.google.maps.android.compose.GoogleMap
import com.google.maps.android.compose.Marker
import com.google.maps.android.compose.MarkerState
import com.google.maps.android.compose.rememberCameraPositionState
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    @SuppressLint("UnusedMaterial3ScaffoldPaddingParameter")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            UT2_GISELA_PGLTheme() {
                Scaffold(modifier = Modifier.fillMaxSize()) {
                    MenuBottomBar()
                }
            }
        }
    }
}
val bd = FirebaseFirestore.getInstance()
val productos = bd.collection("Productos")
var productoslist = mutableStateListOf<Productos>()

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MenuDrawer() {
    val navController = rememberNavController()
    val estadoDrawer = rememberDrawerState(initialValue = DrawerValue.Closed)
    val coroutineScope = rememberCoroutineScope()
    ModalNavigationDrawer(
        drawerContent = {
            ModalDrawerSheet {
                NavigationDrawerItem(
                    label = { Text("Productos")},
                    selected = false,
                    onClick = {
                        navController.navigate("productos")
                        coroutineScope.launch { estadoDrawer.close()}
                    },
                    icon = { Icon(Icons.Filled.Home, null) }
                )
                NavigationDrawerItem(
                    label = { Text("Insertar")},
                    selected = false,
                    onClick = {
                        navController.navigate("insertar")
                        coroutineScope.launch { estadoDrawer.close()}
                    },
                    icon = { Icon(Icons.Filled.Add, null) }
                )
                NavigationDrawerItem(
                    label = { Text("Buscar")},
                    selected = false,
                    onClick = {
                        navController.navigate("buscar")
                        coroutineScope.launch { estadoDrawer.close()}
                    },
                    icon = {Icon(Icons.Filled.Search, null)}
                )
                NavigationDrawerItem(
                    label = { Text("Eliminar")},
                    selected = false,
                    onClick = {
                        navController.navigate("eliminar")
                        coroutineScope.launch { estadoDrawer.close()}
                    },
                    icon = {Icon(Icons.Filled.Delete, null)}
                )
                NavigationDrawerItem(
                    label = { Text("Todos")},
                    selected = false,
                    onClick = {
                        rellenaLista()
                        navController.navigate("todos")
                        coroutineScope.launch { estadoDrawer.close()}
                    },
                    icon = {Icon(Icons.Filled.Menu, null)}
                )
            }
        },
        drawerState = estadoDrawer
    ) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = {
                        Text("SPUT2 GiselaRM PGL")
                    },
                    navigationIcon = {
                        IconButton(
                            onClick = {
                                coroutineScope.launch { estadoDrawer.open() }
                            }
                        ) {
                            Icon(Icons.Filled.Menu, contentDescription = null)
                        }
                    }
                )
            },
            content = { innerPadding ->
                NavHost(
                    navController = navController,
                    startDestination = "productos",
                    Modifier.padding(innerPadding)
                ) {
                    composable("productos") {
                        PantallaProductos()
                    }
                    composable("insertar") {
                        Pantallainsertar()
                    }
                    composable("buscar") {
                        Pantallabuscar()
                    }
                    composable("eliminar") {
                        Pantallaeliminar()
                    }
                    composable("todos") {
                        Pantallatodos()
                    }
                }
            }
        )
    }
}

@Composable
fun MenuBottomBar() {
    val navController = rememberNavController()
    Scaffold(
        bottomBar = {
            NavigationBar {
                NavigationBarItem(
                    label = { Text("Inicio") },
                    selected = true,
                    onClick = {
                        navController.navigate("inicio")
                    },
                    icon = { Icon(Icons.Filled.Home, null) }
                )
                NavigationBarItem(
                    label = { Text("Mapa") },
                    selected = false,
                    onClick = {
                        navController.navigate("mapa")
                    },
                    icon = { Icon(Icons.Filled.Home, null) }
                )
                NavigationBarItem(
                    label = { Text("Hilos") },
                    selected = false,
                    onClick = {
                        navController.navigate("hilos")
                    },
                    icon = { Icon(Icons.Filled.Build, null) }
                )
                NavigationBarItem(
                    label = { Text("Productos") },
                    selected = false,
                    onClick = {
                        navController.navigate("productos")
                    },
                    icon = { Icon(Icons.Filled.List, null) }
                )
            }
        }
    ) { innerPadding ->
        NavHost(
            navController = navController,
            startDestination = "inicio",
            Modifier.padding(innerPadding)
        ) {
            composable("inicio") {
                PantallaInicio()
            }
            composable("mapa") {
                PantallaMapa()
            }
            composable ("hilos"){
                PantallaHilos()
            }
            composable ("productos"){
                MenuDrawer()
            }
        }
    }
}

@Composable
fun PantallaInicio() {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(text = "SPUT2 Versión 1.0", fontSize = 30.sp, fontWeight = FontWeight.Bold)
        Text(text = "Gisela Rodríguez Mayor - 10/12/2025", fontSize = 20.sp, fontWeight = FontWeight.SemiBold)
    }
}
@Composable
fun PantallaMapa() {
    val localizacion = LatLng(28.1291, -15.4339)
    val cameraPositionState = rememberCameraPositionState{
        position = CameraPosition.fromLatLngZoom(localizacion,10f)
    }
    GoogleMap(
        modifier = Modifier.fillMaxSize(),
        cameraPositionState = cameraPositionState
    ) {
        Marker(
            state = MarkerState(position = localizacion),
            title = "Estadio Insular",
            snippet = "Marcador en el Estadio Insular de Las Palmas de Gran Canaria"
        )
    }
}
@Composable
fun PantallaHilos() {
    var numerousuario by remember { mutableStateOf("") }
    var mensajecorrutina by remember { mutableStateOf("") }
    var resultado by remember { mutableStateOf("") }
    val hilosCorrutina = rememberCoroutineScope()
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("Corrutinas Hilos", fontSize = 20.sp, fontWeight = FontWeight.Bold)
        OutlinedTextField(
            value = numerousuario,
            onValueChange = { numerousuario = it.filter { char -> char.isDigit() } },
            label = { Text(text = "Introduce un número") },
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 16.dp),
            singleLine = true
        )
        Text(mensajecorrutina)
        Text(resultado, fontSize = 16.sp)
        Button(
            onClick = {
                val limite = numerousuario.toLongOrNull()
                if (limite == null || limite < 0) {
                    mensajecorrutina = "Introduce un número válido (mayor que 0)"
                    resultado = ""
                } else {
                    hilosCorrutina.launch(Dispatchers.Default) {
                        mensajecorrutina = "Calculando hasta $limite..."
                        resultado = ""
                        val secuencia = mutableListOf<Long>()
                        var a = 0L
                        var b = 1L
                        var actual = 0L
                        if (limite >= 0L) {
                            secuencia.add(a)
                            resultado = secuencia.joinToString(", ")
                            simulaTarea()
                        }
                        if (limite >= 1L) {
                            secuencia.add(b)
                            resultado = secuencia.joinToString(", ")
                            simulaTarea()
                        }
                        while (true) {
                            actual = a + b
                            if (actual > limite) break
                            secuencia.add(actual)
                            resultado = secuencia.joinToString(", ")
                            simulaTarea()
                            a = b
                            b = actual
                        }
                        mensajecorrutina = "Corrutina finalizada. ${secuencia.size} números en la secuencia."
                    }
                }
            },
        ) {
            Text(text = "Calcular")
        }
    }
}
fun simulaTarea() {
    try {
        Thread.sleep(1000)
    } catch (_: InterruptedException) {}
}

@Composable
fun PantallaProductos() {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(text = "Productos", fontSize = 30.sp, fontWeight = FontWeight.Bold)
        Text(text = "Selecciona en el menú drawer la opción que quieres realizar", fontSize = 20.sp, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
    fun Pantallainsertar() {
        val contexto = LocalContext.current
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(text = "Insertar", fontSize = 30.sp, fontWeight = FontWeight.Bold)
            var codigo by remember { mutableStateOf("")}
            var nombre by remember { mutableStateOf("") }
            var precio by remember { mutableStateOf("") }
            var proveedor by remember { mutableStateOf("") }
            var categoria by remember { mutableStateOf("") }
            var stock by remember { mutableStateOf("") }
            OutlinedTextField(
                value = codigo,
                onValueChange = { codigo = it },
                label = { Text(text = "Código") },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                singleLine = true
            )
            OutlinedTextField(
                value = nombre,
                onValueChange = { nombre = it },
                label = { Text(text = "Nombre") },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                singleLine = true
            )
            OutlinedTextField(
                value = precio,
                onValueChange = { precio = it },
                label = { Text(text = "Precio") },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                singleLine = true
            )
            OutlinedTextField(
                value = proveedor,
                onValueChange = { proveedor = it },
                label = { Text(text = "Proveedor") },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                singleLine = true
            )
            OutlinedTextField(
                value = categoria,
                onValueChange = { categoria = it },
                label = { Text(text = "Categoría") },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                singleLine = true
            )
            OutlinedTextField(
                value = stock,
                onValueChange = { stock = it },
                label = { Text(text = "Stock") },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                singleLine = true
            )
            Button(
                onClick = {
                    val productos = Productos(codigo, nombre, precio.toDouble(), proveedor, categoria, stock.toInt())
                    com.giselarm.ut2_gisela_pgl.productos.document(codigo).set(productos)
                    Toast.makeText(contexto, "Registro Insertado", Toast.LENGTH_SHORT).show()
                    codigo = ""
                    nombre = ""
                    precio = ""
                    proveedor = ""
                    categoria = ""
                    stock = ""
                }
            ) {
                Text("Insertar")
            }
        }
    }
@Composable
fun Pantallabuscar() {
    val contexto = LocalContext.current
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(text = "Buscar por código", fontSize = 30.sp, fontWeight = FontWeight.Bold)
        var codigo by remember { mutableStateOf("") }
        var nombreproducto by remember { mutableStateOf("") }
        var precioproducto by remember { mutableStateOf("") }
        var proveedorproducto by remember { mutableStateOf("") }
        var categoriaproducto by remember { mutableStateOf("") }
        var stockproducto by remember { mutableStateOf("") }
        OutlinedTextField(
            value = codigo,
            onValueChange = { codigo = it },
            label = { Text(text = "Código") },
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            singleLine = true
        )
        Text(text = "Nombre del producto: $nombreproducto")
        Text(text = "Precio del producto: $precioproducto")
        Text(text = "Proveedor del producto: $proveedorproducto")
        Text(text = "Categoría del producto: $categoriaproducto")
        Text(text = "Stock del producto: $stockproducto")
        Button(
            onClick = {
                nombreproducto = ""
                precioproducto = ""
                proveedorproducto = ""
                categoriaproducto = ""
                stockproducto = ""
                if (codigo.isBlank()) {
                    Toast.makeText(contexto, "Tienes que introducir el código del producto", Toast.LENGTH_SHORT).show()
                    return@Button
                }
                productos.document(codigo).get().addOnSuccessListener { document ->
                    if (document.exists()) {
                        nombreproducto = document.getString("nombre").orEmpty()
                        precioproducto = document.getDouble("precio")?.toString().orEmpty()
                        proveedorproducto = document.getString("proveedor").orEmpty()
                        categoriaproducto = document.getString("categoria").orEmpty()
                        stockproducto = document.getDouble("stock")?.toString().orEmpty()
                        Toast.makeText(contexto, "Registro encontrado", Toast.LENGTH_SHORT).show()
                    } else {
                        Toast.makeText(contexto, "Registro no encontrado", Toast.LENGTH_SHORT).show()
                    }
                }.addOnFailureListener {
                    Toast.makeText(contexto, "Error al buscar el registro", Toast.LENGTH_SHORT).show()
                }
            }
        ) {
            Text("Buscar por código")
        }
    }
}

@Composable
fun Pantallaeliminar() {
    val contexto = LocalContext.current
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(text = "Eliminar", fontSize = 30.sp, fontWeight = FontWeight.Bold)
        var codigo by remember { mutableStateOf("") }
        OutlinedTextField(
            value = codigo,
            onValueChange = { codigo = it },
            label = { Text(text = "Matricula") },
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            singleLine = true
        )
        Button(
            onClick = {
                productos.document(codigo).get().addOnSuccessListener {
                    if (it.exists()) {
                        it.reference.delete()
                        Toast.makeText(contexto, "Registro eliminado", Toast.LENGTH_SHORT).show()
                    } else {
                        Toast.makeText(contexto, "Registro no encontrado", Toast.LENGTH_SHORT).show()
                    }
                }
            }
        ) {
            Text("Borrar por matricula")
        }
    }
}

@Composable
    fun Pantallatodos() {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp)
        ) {
            items(productoslist) {
                    productostotal -> MostrarProductos(productostotal)
            }
        }
    }
@Composable
    fun MostrarProductos(eq: Productos) {
        HorizontalDivider(modifier = Modifier.fillMaxWidth().width(16.dp))
        Text(text = "Código: ${eq.codigo}")
        Text(text = "Nombre: ${eq.nombre}")
        Text(text = "Stock: ${eq.stock}")
        Text(text = "Proveedor: ${eq.proveedor}")
        Text(text = "Categoría: ${eq.categoria}")
        Text(text = "Stock: ${eq.stock}")
    }
fun rellenaLista() {
        productoslist.clear()
        productos.get().addOnSuccessListener {
            for(docum in it) {
                val prod = Productos(
                    docum.data.get("codigo").toString(),
                    docum.data.get("nombre").toString(),
                    docum.data.get("precio").toString().toDouble(),
                    docum.data.get("proveedor").toString(),
                    docum.data.get("categoria").toString(),
                    docum.data.get("stock").toString().toInt()
                )
                productoslist.add(prod)
            }
        }
    }