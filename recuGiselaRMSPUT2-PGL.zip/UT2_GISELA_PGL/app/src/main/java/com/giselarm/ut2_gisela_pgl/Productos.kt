package com.giselarm.ut2_gisela_pgl

data class Productos(val codigo: String, val nombre: String, val precio: Double, val proveedor: String, val categoria: String, val stock: Int) {
    override fun toString(): String {
        return "Vehiculos(codigo='$codigo', nombre='$nombre', precio='$precio', proveedor=$proveedor, categoria=$categoria, stock=$stock)"
    }
}