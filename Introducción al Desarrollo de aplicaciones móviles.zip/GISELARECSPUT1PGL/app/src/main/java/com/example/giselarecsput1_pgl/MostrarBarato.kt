package com.example.giselarecsput1_pgl

import android.content.Intent
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.ListView
import androidx.appcompat.app.AppCompatActivity

class MostrarBarato : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_mostrar_barato)

        val LVVehiculos = findViewById<ListView>(R.id.LVVehiculos)
        val BTVolverMostrar = findViewById<Button>(R.id.BTVolverMostrar)
        val dbHelper = BD(this)
        val bd = dbHelper.writableDatabase
        val datos = mutableListOf<String>()
        val cursor = bd.rawQuery("SELECT Codigo, Marca, Modelo, Anyo, nkilometros, precio FROM Vehiculos", null)

        if (cursor.moveToFirst()) {
            do {
                val Codigo = cursor.getInt(0)
                val Marca = cursor.getString(1)
                val Modelo = cursor.getString(2)
                val Anyo = cursor.getInt(3)
                val nkilometros = cursor.getInt(4)
                val precio = cursor.getInt(5)

                datos.add("$Codigo - $Marca ($Modelo, $Anyo, $nkilometros, $precio)")
            } while (cursor.moveToNext())
        }

        cursor.close()
        bd.close()

        val adapter = ArrayAdapter(
            this,
            android.R.layout.simple_list_item_1,
            datos
        )

        LVVehiculos.adapter = adapter

        BTVolverMostrar.setOnClickListener {
            startActivity(Intent(this, MainActivity::class.java))
        }
    }
}