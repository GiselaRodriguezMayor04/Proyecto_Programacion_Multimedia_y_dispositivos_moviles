package com.example.giselarecsput1_pgl

import android.content.Intent
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.ListView
import androidx.appcompat.app.AppCompatActivity

class MostrarKm: AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_mostrar_km)

        //val SPMostrarKm = findViewById<ListView>(R.id.SPMostrarKm)
        val BTVolverMostrarKm = findViewById<Button>(R.id.BTVolverMostrarKm)
        val dbHelper = BD(this)
        val bd = dbHelper.writableDatabase
        val datos = mutableListOf<String>()
        val cursor = bd.rawQuery("SELECT Codigo, Precio  FROM Vehiculos", null)

        if (cursor.moveToFirst()) {
            do {
                val Codigo = cursor.getInt(0)
                val Precio = cursor.getInt(1)

                datos.add("$Codigo - $Precio")
            } while (cursor.moveToNext())
        }

        cursor.close()
        bd.close()

        val adapter = ArrayAdapter(
            this,
            android.R.layout.simple_list_item_1,
            datos
        )

        //SPMostrarKm.adapter = adapter

        BTVolverMostrarKm.setOnClickListener {
            startActivity(Intent(this, MainActivity::class.java))
        }
    }
}