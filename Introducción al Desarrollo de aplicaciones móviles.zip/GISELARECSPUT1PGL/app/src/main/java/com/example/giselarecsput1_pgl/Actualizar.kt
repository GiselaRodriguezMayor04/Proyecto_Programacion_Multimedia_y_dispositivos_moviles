package com.example.giselarecsput1_pgl

import android.content.ContentValues
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class Actualizar : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_actualizar)

        val ETCodigoMod = findViewById<EditText>(R.id.ETCodigoMod)
        val ETPrecioBase = findViewById<EditText>(R.id.ETPrecioBase)
        val ETPrecioMod = findViewById<EditText>(R.id.ETPrecioMod)
        val BTMod = findViewById<Button>(R.id.BTMod)
        val BTVolverMod = findViewById<Button>(R.id.BTVolverMod)

        BTMod.setOnClickListener {
            if (ETCodigoMod.text.isEmpty() || ETPrecioBase.text.isEmpty() || ETPrecioMod.text.isEmpty()) {
                Toast.makeText(this, "Debe rellenar el codigo y los nuevos datos.", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            try {
                val CodigoMod = ETCodigoMod.text.toString().toInt()
                val PrecioBase = ETPrecioBase.text.toString().toInt()
                val PrecioMod = ETPrecioMod.text.toString().toInt()

                val dbHelper = BD(this)
                val bd = dbHelper.writableDatabase

                val registro = ContentValues()
                registro.put("PrecioBase", PrecioBase)
                registro.put("PrecioMod", PrecioMod)

                val count = bd.update(
                    "Vehiculos",
                    registro,
                    "Codigo = ?",
                    arrayOf(CodigoMod.toString())
                )

                bd.close()

                if (count > PrecioBase) {
                    Toast.makeText(this, "Vehiculo con codigo $CodigoMod actualizado correctamente.", Toast.LENGTH_SHORT).show()
                    ETCodigoMod.setText("")
                    ETPrecioBase.setText("")
                    ETPrecioMod.setText("")
                } else {
                    Toast.makeText(this, "Error: Codigo $CodigoMod no encontrado o no se realizaron cambios.", Toast.LENGTH_SHORT).show()
                }
            } catch (e: NumberFormatException) {
                Toast.makeText(this, "Error: El codigo debe ser un número válido.", Toast.LENGTH_SHORT).show()
            }
        }

        BTVolverMod.setOnClickListener {
            startActivity(Intent(this, MainActivity::class.java))
        }
    }
}