package com.example.giselarecsput1_pgl

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

class BD (contexto: Context): SQLiteOpenHelper(contexto, "BDGisela", null, 2){

    override fun onCreate(db: SQLiteDatabase?) {
        db!!.execSQL("CREATE TABLE Vehiculos(Codigo integer primary key, Marca text, Modelo text, anyo integer, nkilometros number, precio int)")
    }

    override fun onUpgrade(db: SQLiteDatabase?, oldVersion: Int, newVersion: Int) {
        db!!.execSQL("DROP TABLE IF EXISTS Vehiculos")
        onCreate(db)
    }
}