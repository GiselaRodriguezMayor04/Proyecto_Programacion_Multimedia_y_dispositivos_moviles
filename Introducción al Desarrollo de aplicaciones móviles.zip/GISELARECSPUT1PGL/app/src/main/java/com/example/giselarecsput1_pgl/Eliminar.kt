package com.example.giselarecsput1_pgl

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class Eliminar : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_eliminar)

        val ETEliminar = findViewById<EditText>(R.id.ETEliminar)
        val BTEliminarVehiculo = findViewById<Button>(R.id.BTEliminarVehiculo)
        val BTVolver = findViewById<Button>(R.id.BTVolverEliminar)

        BTEliminarVehiculo.setOnClickListener {
            if(ETEliminar.text.isEmpty()) {
                muestraMensaje("El campo no puede estar vacío.")
                return@setOnClickListener
            }

            try {
                val dbHelper = BD(this)
                val bd = dbHelper.writableDatabase
                val VehiculoEliminado = ETEliminar.text.toString().toInt()
                val reg = bd.delete("Vehiculos","Codigo = ?", arrayOf(VehiculoEliminado.toString()))

                bd.close()

                if(reg == 1) {
                    muestraMensaje("Vehiculo con Codigo $VehiculoEliminado Eliminado.")
                } else {
                    muestraMensaje("No se ha podido eliminar el vehiculo con codigo $VehiculoEliminado porque no existe.")
                }

            } catch (e: NumberFormatException) {
                muestraMensaje("Error: El codigo debe ser un número válido.")
            }
        }

        BTVolver.setOnClickListener {
            startActivity(Intent(this, MainActivity::class.java))
        }
    }
    private fun muestraMensaje(s: String) {
        Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
    }
}