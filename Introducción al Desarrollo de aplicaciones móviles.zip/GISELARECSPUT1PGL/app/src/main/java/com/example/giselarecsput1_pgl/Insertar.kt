package com.example.giselarecsput1_pgl

import android.annotation.SuppressLint
import android.content.ContentValues
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class Insertar : AppCompatActivity() {
    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_insertar)

        val ETCodigoInsertar = findViewById<EditText>(R.id.ETCodigoInsertar)
        val ETMarcaInsertar = findViewById<EditText>(R.id.ETMarcaInsertar)
        val ETModeloInsertar = findViewById<EditText>(R.id.ETModeloInsertar)
        val ETAnyoInsertar = findViewById<EditText>(R.id.ETAnyoInsertar)
        val ETNkmInsertar = findViewById<EditText>(R.id.ETNkmInsertar)
        val ETPrecioInsertar = findViewById<EditText>(R.id.ETPrecioInsertar)
        val BTGuardar = findViewById<Button>(R.id.BTGuardar)
        val BTVolverInsertar = findViewById<Button>(R.id.BTVolverInsertar)

        BTGuardar.setOnClickListener {
            if (ETCodigoInsertar.text.isEmpty() || ETMarcaInsertar.text.isEmpty() || ETAnyoInsertar.text.isEmpty() || ETModeloInsertar.text.isEmpty() || ETNkmInsertar.text.isEmpty() || ETPrecioInsertar.text.isEmpty()) {
                Toast.makeText(this, "Tienes que rellenar todos los campos", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            try {
                val dbHelper = BD(this)
                val bd = dbHelper.writableDatabase
                val registro = ContentValues()
                registro.put("Codigo", ETCodigoInsertar.text.toString().toInt())
                registro.put("Marca", ETMarcaInsertar.text.toString())
                registro.put("Modelo", ETModeloInsertar.text.toString())
                registro.put("Anyo", ETAnyoInsertar.text.toString().toInt())
                registro.put("NKilometros", ETNkmInsertar.text.toString().toInt())
                registro.put("Precio", ETPrecioInsertar.text.toString().toDouble())

                val resultado = bd.insert("Vehiculos", null, registro)

                bd.close()

                if (resultado != -1L) {
                    muestraMensaje("Registro insertado correctamente.")
                } else {
                    muestraMensaje("Error al insertar: ID ya existe o dato inválido.")
                }
            } catch (e: NumberFormatException) {
                muestraMensaje("Error: La ID debe ser un número válido.")
            }
        }

        BTVolverInsertar.setOnClickListener {
            startActivity(Intent(this, MainActivity::class.java))
        }
    }
    private fun muestraMensaje(s: String) {
        Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
    }
}