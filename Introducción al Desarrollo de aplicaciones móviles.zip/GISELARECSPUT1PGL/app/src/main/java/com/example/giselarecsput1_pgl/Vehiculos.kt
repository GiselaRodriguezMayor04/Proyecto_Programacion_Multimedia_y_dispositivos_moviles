package com.example.giselarecsput1_pgl

data class Vehiculos(
    val Codigo: Int,
    val Marca: String,
    val Modelo: String,
    val Anyo: Int,
    val Nkilometros: Number,
    val Precio: Int
)