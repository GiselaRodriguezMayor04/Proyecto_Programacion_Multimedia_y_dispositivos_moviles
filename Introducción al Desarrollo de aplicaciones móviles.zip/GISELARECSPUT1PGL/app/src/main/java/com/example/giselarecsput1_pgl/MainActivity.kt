package com.example.giselarecsput1_pgl

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val BTInsertar = findViewById<Button>(R.id.BTInsertar)
        val BTMostrarKm = findViewById<Button>(R.id.BTMostrarKm)
        val BTActualizar = findViewById<Button>(R.id.BTActualizar)
        val BTMostrarBarato = findViewById<Button>(R.id.BTMostrarBarato)
        val BTEliminar = findViewById<Button>(R.id.BTEliminar)
        //val BTBuscar = findViewById<Button>(R.id.BTBuscar)

        BTInsertar.setOnClickListener {
            startActivity(Intent(this, Insertar::class.java))
        }
        BTMostrarKm.setOnClickListener {
            startActivity(Intent(this, MostrarKm::class.java))
        }
        BTActualizar.setOnClickListener {
            startActivity(Intent(this, Actualizar::class.java))
        }
        BTMostrarBarato.setOnClickListener {
    startActivity(Intent(this, MostrarBarato::class.java))
        }
        BTEliminar.setOnClickListener {
            startActivity(Intent(this, Eliminar::class.java))
        }
        /*BTBuscar.setOnClickListener {
            startActivity(Intent(this, Buscar::class.java))
        }*/
    }
}